create definer = root@localhost trigger check_max_members_before_insert
    before insert
    on `groups`
    for each row
BEGIN
    IF NEW.max_members < 1 OR NEW.max_members > 12 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'max_members 값이 허용되는 범위를 벗어났습니다.';
    END IF;
END;

